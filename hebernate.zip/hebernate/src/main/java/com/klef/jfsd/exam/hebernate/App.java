package com.klef.jfsd.exam.hebernate;
import jakarta.persistence.*;
import jakarta.persistence.criteria.*;
import java.util.List;

public class App {
    public static void main(String[] args) {
        // Create EntityManagerFactory
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("labexamPU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();

        // Insert Data
        insertCustomers(em);

        // Perform Criteria Queries
        performCriteriaQueries(em);

        em.getTransaction().commit();
        em.close();
        emf.close();
    }

    private static void insertCustomers(EntityManager em) {
        Customer c1 = new Customer();
        c1.setName("Alice");
        c1.setEmail("alice@example.com");
        c1.setAge(25);
        c1.setLocation("New York");

        Customer c2 = new Customer();
        c2.setName("Bob");
        c2.setEmail("bob@example.com");
        c2.setAge(30);
        c2.setLocation("Los Angeles");

        Customer c3 = new Customer();
        c3.setName("Charlie");
        c3.setEmail("charlie@example.com");
        c3.setAge(22);
        c3.setLocation("Chicago");

        em.persist(c1);
        em.persist(c2);
        em.persist(c3);

        System.out.println("Customers inserted successfully!");
    }

    private static void performCriteriaQueries(EntityManager em) {
        CriteriaBuilder cb = em.getCriteriaBuilder();

        // Equal Restriction
        CriteriaQuery<Customer> query = cb.createQuery(Customer.class);
        Root<Customer> root = query.from(Customer.class);
        query.select(root).where(cb.equal(root.get("location"), "New York"));
        List<Customer> result = em.createQuery(query).getResultList();
        System.out.println("Customers from New York: " + result);

        // Between Restriction
        query = cb.createQuery(Customer.class);
        root = query.from(Customer.class);
        query.select(root).where(cb.between(root.get("age"), 20, 30));
        result = em.createQuery(query).getResultList();
        System.out.println("Customers aged between 20 and 30: " + result);

        // Like Restriction
        query = cb.createQuery(Customer.class);
        root = query.from(Customer.class);
        query.select(root).where(cb.like(root.get("name"), "A%"));
        result = em.createQuery(query).getResultList();
        System.out.println("Customers with names starting with 'A': " + result);

        // Greater Than Restriction
        query = cb.createQuery(Customer.class);
        root = query.from(Customer.class);
        query.select(root).where(cb.gt(root.get("age"), 25));
        result = em.createQuery(query).getResultList();
        System.out.println("Customers older than 25: " + result);
    }
}
